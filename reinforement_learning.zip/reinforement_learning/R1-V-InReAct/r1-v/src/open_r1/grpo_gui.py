import os
import re
from datetime import datetime
from dataclasses import dataclass, field
from typing import Optional

from datasets import load_dataset, load_from_disk
from transformers import Qwen2VLForConditionalGeneration

from math_verify import parse, verify
from trainer import Qwen2VLGRPOTrainer, Qwen2VLGRPOVLLMTrainer, Qwen2VLGRPOVLLMTrainerModified
from trl import GRPOConfig, GRPOTrainer, ModelConfig, ScriptArguments, get_peft_config

from system_prompt.constant import agent_system_message, chat_template, grounding_system_message, until, user_instruction


@dataclass
class GRPOScriptArguments(ScriptArguments):
    reward_funcs: list[str] = field(
        default_factory=lambda: ["accuracy", "format"],
        metadata={"help": "List of reward functions. Possible values: 'accuracy', 'format'"},
    )
    max_pixels: Optional[int] = field(
        default=12845056,
        metadata={"help": "Maximum number of pixels for the image"},
    )
    min_pixels: Optional[int] = field(
        default=3136,
        metadata={"help": "Minimum number of pixels for the image"},
    )


def extract_action_json(text):
    """
    提取 JSON 格式的动作，例如 {"type": "click", "args": {"x": 0.364, "y": 0.135}}
    """
    match = re.search(r'\{.*?\}', text, re.DOTALL)
    if not match:
        return None
    try:
        import json
        return json.loads(match.group(0))
    except Exception as e:
        print(f"JSON parsing error: {e}")
        return None


def accuracy_reward(completions, solution, **kwargs):
    contents = [completion[0]["content"] for completion in completions]
    rewards = []

    for content, sol in zip(contents, solution):
        reward = 0.0
        try:
            # 解析 ground truth 和 prediction
            gt = extract_action_json(sol)
            pred = extract_action_json(content)

            if not gt or not pred:
                continue

            # 检查 action type 是否一致
            if gt["type"] == pred["type"]:
                reward += 0.5

                # 检查坐标距离
                x_gt, y_gt = gt["args"]["x"], gt["args"]["y"]
                x_pred, y_pred = pred["args"].get("x", 0), pred["args"].get("y", 0)
                distance = ((x_gt - x_pred) ** 2 + (y_gt - y_pred) ** 2) ** 0.5

                # 奖励分段
                if distance <= 0.1:
                    reward += 0.5
                elif distance <= 0.3:
                    reward += 0.3
                elif distance <= 0.5:
                    reward += 0.2
        except Exception as e:
            print(f"Error calculating accuracy reward: {e}")
            pass

        rewards.append(reward)

        if os.getenv("DEBUG_MODE") == "true":
            current_time = datetime.now().strftime("%d-%H-%M-%S-%f")
            log_path = os.getenv("LOG_PATH")
            with open(log_path, "a") as f:
                f.write(f"------------- {current_time} Accuracy reward: {reward} -------------\n")
                f.write(f"Content: {content}\n")
                f.write(f"Solution: {sol}\n")

    return rewards


def format_reward(completions, solution, **kwargs):
    contents = [completion[0]["content"] for completion in completions]
    return [1.0 if extract_action_json(c) is not None else 0.0 for c in contents]


reward_funcs_registry = {
    "accuracy": accuracy_reward,
    "format": format_reward,
}

SYSTEM_PROMPT = agent_system_message + (
    "You need to provide the user with a pre-defined function in structured JSON format.\n"
    "Example:\n"
    '{"type": "click", "args": {"x": 0.797, "y": 0.219}}'
)


def main(script_args, training_args, model_args):
    reward_funcs = [reward_funcs_registry[func] for func in script_args.reward_funcs]

    dataset = load_dataset(script_args.dataset_name, name=script_args.dataset_config)

    def make_conversation(example):
        return {
            "prompt": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": example["problem"]},
            ],
        }

    QUESTION_TEMPLATE = "{Question}"

    def make_conversation_image(example):
        return {
            "prompt": [
                {
                    "role": "user",
                    "content": [
                        {"type": "image"},
                        {"type": "text", "text": QUESTION_TEMPLATE.format(Question=example["problem"])},
                    ],
                },
            ],
        }

    if "image" in dataset[script_args.dataset_train_split].features:
        print("has image in dataset")
        dataset = dataset.map(make_conversation_image)
    else:
        print("no image in dataset")
        dataset = dataset.map(make_conversation)
        dataset = dataset.remove_columns("messages")

    trainer_cls = Qwen2VLGRPOTrainer if not training_args.use_vllm else Qwen2VLGRPOVLLMTrainerModified
    print("using: ", trainer_cls)

    trainer = trainer_cls(
        model=model_args.model_name_or_path,
        reward_funcs=reward_funcs,
        args=training_args,
        train_dataset=dataset[script_args.dataset_train_split],
        eval_dataset=dataset[script_args.dataset_test_split] if training_args.eval_strategy != "no" else None,
        peft_config=get_peft_config(model_args),
        attn_implementation=model_args.attn_implementation,
        max_pixels=script_args.max_pixels,
        min_pixels=script_args.min_pixels,
    )

    trainer.train()
    trainer.save_model(training_args.output_dir)
    if training_args.push_to_hub:
        trainer.push_to_hub(dataset_name=script_args.dataset_name)


if __name__ == "__main__":
    parser = TrlParser((GRPOScriptArguments, GRPOConfig, ModelConfig))
    script_args, training_args, model_args = parser.parse_args_and_config()
    main(script_args, training_args, model_args)