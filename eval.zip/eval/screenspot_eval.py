import os
import sys
import re
import json
import torch
import numpy as np
from PIL import Image, ImageDraw
from tqdm import tqdm
from transformers import Qwen2VLForConditionalGeneration, AutoTokenizer, AutoProcessor
from qwen_vl_utils import process_vision_info
import re

def extract_coordinates_from_pyautogui(output_text):
    """
    从pyautogui操作中提取归一化坐标
    支持格式示例:
    - pyautogui.click(x=0.5, y=0.5)
    - pyautogui.moveTo(0.3, 0.4)
    - pyautogui.doubleClick(x=0.1,y=0.2)
    """
    # 使用正则表达式匹配坐标
    patterns = [
        r"pyautogui\.\w+\(x=([0-9.]+),\s*y=([0-9.]+)\)",  # 匹配 x=0.1, y=0.2 格式
        r"pyautogui\.\w+\(([0-9.]+),\s*([0-9.]+)\)"       # 匹配 0.1, 0.2 格式
    ]
    
    for pattern in patterns:
        match = re.search(pattern, output_text)
        if match:
            try:
                x = float(match.group(1))
                y = float(match.group(2))
                # 确保坐标在0-1范围内
                if 0 <= x <= 1 and 0 <= y <= 1:
                    return [x, y]
            except (ValueError, IndexError):
                continue
    
    return None

def get_center_point(bbox):
    """计算bbox的中心点"""
    return [bbox[0] + bbox[2] / 2, bbox[1] + bbox[3] / 2]

def point_in_bbox(point, gt_bbox, image_size):
    if point == None:
        return True
    """判断点是否在gt_bbox内"""
    width, height = image_size
    abs_x = point[0] * width
    abs_y = point[1] * height
    
    abs_x1 = gt_bbox[0]
    abs_y1 = gt_bbox[1]
    abs_w = gt_bbox[2]
    abs_h = gt_bbox[3]
    
    abs_x2 = abs_x1 + abs_w
    abs_y2 = abs_y1 + abs_h
    # print((abs_x1 <= abs_x <= abs_x2) and (abs_y1 <= abs_y <= abs_y2))
    return (abs_x1 <= abs_x <= abs_x2) and (abs_y1 <= abs_y <= abs_y2)

def predict_location(model, processor, image, task, system_prompt):
    """使用模型预测位置"""
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": [
            {"type": "image", "image": image},
            {"type": "text", "text": task}
        ]}
    ]

    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    image_inputs, video_inputs = process_vision_info(messages)
    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt"
    ).to(model.device)
    with torch.no_grad():
        generated_ids = model.generate(**inputs, max_new_tokens=128, use_cache=True)
        generated_ids_trimmed = [
            out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        output_text = processor.batch_decode(
            generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]
    
    # 尝试从pyautogui命令中提取坐标
    coordinates = extract_coordinates_from_pyautogui(output_text)
    if coordinates:
        return coordinates, None
    else:
        return None, f"无法从输出中解析坐标: {output_text}"

def load_dataset(data_path):
    """加载ScreenSpot数据集"""
    with open(data_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def calculate_success_rate(results):
    """计算各分类的成功率"""
    metrics = {}
    total_items = []
    
    for category in results:
        items = results[category]
        if len(items) == 0:
            continue
        success = sum(item["success"] for item in items)
        metrics[category] = success / len(items)
        total_items.extend(items)
    
    if total_items:
        metrics["overall"] = sum(item["success"] for item in total_items) / len(total_items)
    
    return metrics

def main():
    # 配置路径
    dataset_dir = "/root/gui-agent/dataset/ScreenSpot"
    json_path = os.path.join(dataset_dir, "metadata/hf_test_full.json")
    images_dir = os.path.join(dataset_dir, "images")
    vis_dir = os.path.join("results", "vis_1000_rl_1344")
    os.makedirs(vis_dir, exist_ok=True)

    # 加载数据
    print("正在加载数据集...")
    data = load_dataset(json_path)
    print(f"数据集加载完成，共{len(data)}条数据")

    # 初始化模型
    print("正在加载模型...")
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        # "/root/autodl-tmp/model/checkpoint-121200",
        #"./checkpoint-500",
        # "/root/autodl-tmp/model/checkpoint-500_full",
        "/root/autodl-tmp/model/checkpoint-1000_rl",
        torch_dtype=torch.bfloat16,
        device_map="auto",
        attn_implementation="flash_attention_2"
    )
    processor = AutoProcessor.from_pretrained(
        "Qwen/Qwen2-VL-2B-Instruct",
        min_pixels=256*28*28,
        max_pixels=46*26*28*28,
        use_fast=True
    )
    model.gradient_checkpointing_disable()
    model.eval()
    print("模型加载完成")
    
    system_prompt = "You are a GUI agent. You are given a task and a screenshot of the screen. You need to perform a series of pyautogui actions to complete the task."

    # 初始化结果记录
    results = {
        "desktop icon": [],
        "desktop text": [],
        "mobile icon": [],
        "mobile text": [],
        "web icon": [],
        "web text": []
    }
    
    # 计数器
    counters = {category: {"total": 0, "success": 0} for category in results}

    # 开始评测
    print("开始评测...")
    for item in tqdm(data):
        split = item["split"]
        data_type = item["data_type"]
        category = f"{split} {data_type}"
        
        # 构建图像路径
        img_path = os.path.join(images_dir, item["img_url"])
        if not os.path.exists(img_path):
            print(f"图像不存在: {img_path}，跳过")
            continue

        # 加载图片
        image = Image.open(img_path).convert("RGB")
        task = item["task"]
        
        # 更新计数器
        counters[category]["total"] += 1
        
        # 预测位置
        pred_point, error = predict_location(model, processor, image, task, system_prompt)
        
        if error:
            # 预测失败
            print(f"预测失败: {error}")
            results[category].append({
                "id": item["id"],
                "task": task,
                "img_url": item["img_url"],
                "pred_text": str(error),
                "gt_bbox": item["bbox"],
                "success": 0
            })
            continue
        
        # 判断预测是否成功
        success = point_in_bbox(pred_point, item["bbox"], (image.width, image.height))
        if success:
            counters[category]["success"] += 1
        
        # 记录结果
        results[category].append({
            "id": item["id"],
            "task": task,
            "img_url": item["img_url"],
            "pred_point": pred_point,
            "gt_bbox": item["bbox"],
            "success": int(success),
            "output_text": error if error else "Success"
        })

        # 可视化（每20个样本保存一次）
        if int(item["id"].split("_")[-1]) % 20 == 0:
            vis_image = image.copy()
            draw = ImageDraw.Draw(vis_image)
            
            # 绘制预测点（蓝色）
            x, y = pred_point[0] * image.width, pred_point[1] * image.height
            draw.ellipse((x-10, y-10, x+10, y+10), fill='blue')
            
            # 绘制真实bbox（黄色）
            gt_x, gt_y, gt_w, gt_h = item["bbox"]
            draw.rectangle((
                gt_x * image.width, 
                gt_y * image.height,
                (gt_x + gt_w) * image.width,
                (gt_y + gt_h) * image.height
            ), outline='yellow', width=2)
            
            # 添加文本标注
            draw.text((10, 10), f"Task: {task}", fill="red")
            draw.text((10, 30), f"Pred: ({pred_point[0]:.2f}, {pred_point[1]:.2f})", fill="red")
            
            vis_image.save(os.path.join(vis_dir, f"{item['id']}.png"))

    # 计算成功率
    metrics = calculate_success_rate(results)

    # 打印结果
    print("\n评测结果：")
    print("="*50)
    for category in sorted(metrics.keys()):
        if category == "overall":
            continue
        total = counters[category]["total"]
        success = counters[category]["success"]
        print(f"{category:15s}: {success:3d}/{total:3d} = {metrics[category]:.4f}")
    print(f"\n{'Overall':15s}: {'':3s} {'':3s} = {metrics['overall']:.4f}")

    # 保存结果
    output_dir = "results/screenspot_rl_1000_1344"
    os.makedirs(output_dir, exist_ok=True)
    
    with open(os.path.join(output_dir, "results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    with open(os.path.join(output_dir, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)

    print(f"\n结果已保存到 {output_dir} 目录")
    print(f"可视化结果已保存到 {vis_dir} 目录")

if __name__ == "__main__":
    main()