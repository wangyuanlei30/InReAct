import os
import sys
import ast
import json
import torch
import numpy as np
from PIL import Image, ImageDraw
from tqdm import tqdm
from pathlib import Path
from io import BytesIO
from transformers import Qwen2VLForConditionalGeneration, AutoTokenizer, AutoProcessor
from qwen_vl_utils import process_vision_info
import re

def extract_coordinates_from_pyautogui(output_text):
    """
    从pyautogui操作中提取归一化坐标
    支持格式示例:
    - pyautogui.click(x=0.5, y=0.5)
    - pyautogui.moveTo(0.3, 0.4)
    - pyautogui.doubleClick(x=0.1,y=0.2)
    """
    # 使用正则表达式匹配坐标
    patterns = [
        r"pyautogui\.\w+\(x=([0-9.]+),\s*y=([0-9.]+)\)",  # 匹配 x=0.1, y=0.2 格式
        r"pyautogui\.\w+\(([0-9.]+),\s*([0-9.]+)\)"       # 匹配 0.1, 0.2 格式
    ]
    
    for pattern in patterns:
        match = re.search(pattern, output_text)
        if match:
            try:
                x = float(match.group(1))
                y = float(match.group(2))
                # 确保坐标在0-1范围内
                if 0 <= x <= 1 and 0 <= y <= 1:
                    return [x, y]
            except (ValueError, IndexError):
                continue
    
    return None

def get_center_point(bbox):
    """
    计算bbox的中心点
    bbox: [x1, y1, x2, y2] - 绝对坐标
    return: [center_x, center_y]
    """
    center_x = (bbox[0] + bbox[2]) / 2
    center_y = (bbox[1] + bbox[3]) / 2
    return [center_x, center_y]

def convert_bbox_to_relative(bbox, image_size):
    """
    将绝对坐标转换为相对坐标
    bbox: [x1, y1, x2, y2] - 绝对坐标
    image_size: (width, height) - 图像尺寸
    return: [x, y, w, h] - 相对坐标 (0-1)
    """
    width, height = image_size
    x = bbox[0] / width
    y = bbox[1] / height
    w = (bbox[2] - bbox[0]) / width
    h = (bbox[3] - bbox[1]) / height
    return [x, y, w, h]

def point_in_bbox(point, gt_bbox, image_size):
    """
    判断点是否在gt_bbox内
    point: [x, y] - 范围0-1的相对坐标
    gt_bbox: [x1, y1, x2, y2] - 绝对坐标
    image_size: (width, height) - 图像尺寸，用于坐标转换
    """
    # 将相对坐标转换为绝对坐标
    width, height = image_size
    abs_x = point[0] * width
    abs_y = point[1] * height
    
    # 获取bbox边界
    abs_x1 = gt_bbox[0]
    abs_y1 = gt_bbox[1]
    abs_x2 = gt_bbox[2]
    abs_y2 = gt_bbox[3]

    # 判断点是否在bbox内
    if (abs_x1 <= abs_x <= abs_x2) and (abs_y1 <= abs_y <= abs_y2):
        return True
    else:
        return False

def get_subregion(image, center_point, scale=0.5):
    """
    从原图中截取以center_point为中心的子区域，保持原图宽高比
    
    Args:
        image: 原始图像
        center_point: 中心点坐标 [x, y]，范围0-1
        scale: 子区域占原图的比例
    
    Returns:
        子区域图像, 子区域在原图中的坐标 (left, top, right, bottom)
    """
    # 计算子区域的宽高（保持原图宽高比）
    sub_width = int(image.width * scale**0.5)
    sub_height = int(image.height * scale**0.5)
    
    # 计算中心点在原图中的像素坐标
    center_x = int(center_point[0] * image.width)
    center_y = int(center_point[1] * image.height)
    
    # 计算子区域的左上角坐标
    left = max(0, center_x - sub_width // 2)
    top = max(0, center_y - sub_height // 2)
    
    # 确保右下角不超出图像边界
    right = min(image.width, left + sub_width)
    bottom = min(image.height, top + sub_height)
    
    # 如果右边或底部超出边界，调整左上角
    if right == image.width:
        left = max(0, image.width - sub_width)
    if bottom == image.height:
        top = max(0, image.height - sub_height)
    
    # 如果左边或顶部已经是0，调整右下角确保尺寸正确
    if left == 0:
        right = min(image.width, sub_width)
    if top == 0:
        bottom = min(image.height, sub_height)
    
    # 截取子区域
    subregion = image.crop((left, top, right, bottom))
    
    return subregion, (left, top, right, bottom)

def predict_location(model, processor, image, task, system_prompt):
    """使用模型预测位置"""
    # 构造消息
    messages = [
        {
            "role": "system",
            "content": system_prompt
        },
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": task}
            ]
        }
    ]

    # 准备推理
    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    image_inputs, video_inputs = process_vision_info(messages)
    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt"
    )
    inputs = inputs.to(model.device)
    
    # 推理
    with torch.no_grad():
        generated_ids = model.generate(**inputs, max_new_tokens=128, use_cache = True)
        generated_ids_trimmed = [
            out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
        ]
        output_text = processor.batch_decode(
            generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]
    
    # 尝试从pyautogui命令中提取坐标
    coordinates = extract_coordinates_from_pyautogui(output_text)
    if coordinates:
        return coordinates, None
    else:
        return None, f"无法从输出中解析坐标: {output_text}"

def load_dataset(data_path):
    """
    加载ScreenSpot-Pro数据集
    """
    with open(data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data

def calculate_success_rate(results):
    """
    计算各类型数据的成功率
    """
    metrics = {}
    for data_type in results:
        total = len(results[data_type])
        if total == 0:
            continue

        success = sum([item["success"] for item in results[data_type]])
        metrics[f"{data_type}"] = success / total

    # 计算整体成功率
    all_items = []
    for items in results.values():
        all_items.extend(items)

    if len(all_items) > 0:
        overall_success = sum([item["success"] for item in all_items]) / len(all_items)
        metrics["overall"] = overall_success

    return metrics

def main():
    # 数据集路径
    dataset_dir = "/root/gui-agent/dataset/ScreenSpot-Pro"
    annotations_dir = os.path.join(dataset_dir, "annotations")
    images_dir = os.path.join(dataset_dir, "images")
    
    # 创建可视化结果目录
    vis_dir = os.path.join("results", "vis_pro_1000_1344")
    os.makedirs(vis_dir, exist_ok=True)

    # 获取所有注释文件
    annotation_files = [f for f in os.listdir(annotations_dir) if f.endswith('.json')]
    
    if not annotation_files:
        print(f"错误：在 {annotations_dir} 中未找到注释文件")
        return
    
    # 加载所有数据
    all_data = []
    for annotation_file in annotation_files:
        file_path = os.path.join(annotations_dir, annotation_file)
        print(f"正在加载数据集文件: {annotation_file}...")
        data = load_dataset(file_path)
        # 添加文件名作为数据来源标识
        for item in data:
            item["source_file"] = annotation_file
        all_data.extend(data)
    
    print(f"数据集加载完成，共{len(all_data)}条数据")

    # 初始化模型
    print("正在加载模型...")
    # model_id = "showlab/ShowUI-2B"
    # model_id = "/root/autodl-tmp/model/checkpoint-500"
    model_id = "/root/autodl-tmp/model/checkpoint-1000_rl"
    # model_id = "/root/autodl-tmp/model/checkpoint-121200"
    # model_id = "/root/autodl-tmp/model/11/aguvis-7b"
    model = Qwen2VLForConditionalGeneration.from_pretrained(
        model_id,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        attn_implementation="flash_attention_2"
    )
    processor = AutoProcessor.from_pretrained("Qwen/Qwen2-VL-2B-Instruct",
                                              min_pixels=256*28*28, 
                                              max_pixels=1344*28*28
                                            )
    print("模型加载完成")

    # 设置system prompt
    system_prompt = "You are a GUI agent. You are given a task and a screenshot of the screen. You need to perform a series of pyautogui actions to complete the task."

    # 按不同维度分类记录结果
    results = {
        "application": {},  # 按应用分类
        "platform": {},     # 按平台分类
        "ui_type": {},      # 按UI类型分类
        "group": {}         # 按组分类
    }
    
    # 添加二次定位的结果
    results_two_stage = {
        "application": {},
        "platform": {},
        "ui_type": {},
        "group": {}
    }

    # 开始评测
    print("开始评测...")
    
    # 用于实时统计的计数器
    categories = {
        "application": set(),
        "platform": set(),
        "ui_type": set(),
        "group": set()
    }
    
    # 收集所有分类
    for item in all_data:
        for category in categories:
            if category in item:
                categories[category].add(item[category])
    
    # 初始化计数器
    total_count = {}
    success_count_single = {}
    success_count_two_stage = {}
    success_count_either = {}
    
    for category_type, category_values in categories.items():
        total_count[category_type] = {value: 0 for value in category_values}
        success_count_single[category_type] = {value: 0 for value in category_values}
        success_count_two_stage[category_type] = {value: 0 for value in category_values}
        success_count_either[category_type] = {value: 0 for value in category_values}
        
        # 初始化结果字典
        for value in category_values:
            results[category_type][value] = []
            results_two_stage[category_type][value] = []
    
    for item in tqdm(all_data):
        # 构建图像路径
        img_filename = item["img_filename"]
        img_path = os.path.join(images_dir, img_filename)
        if not os.path.exists(img_path):
            print(f"图像不存在: {img_path}，跳过")
            continue

        # 加载并处理图片
        image = Image.open(img_path).convert("RGB")
        
        # 使用英文指令，如果需要中文可以使用 item["instruction_cn"]
        task = item["instruction"]
        
        # 获取图像尺寸
        if "img_size" in item:
            img_width, img_height = item["img_size"]
        else:
            img_width, img_height = image.size
        
        # 第一次预测
        first_pred_point, error = predict_location(model, processor, image, task, system_prompt)
        
        # 更新计数器
        for category_type in categories:
            if category_type in item:
                category_value = item[category_type]
                total_count[category_type][category_value] += 1
        
        if error:
            # 预测失败，记录结果
            print(f"第一次预测失败: {error}")
            gt_bbox = item["bbox"]
            
            # 记录结果到各个分类中
            for category_type in categories:
                if category_type in item:
                    category_value = item[category_type]
                    
                    # 记录结果（一次定位）
                    results[category_type][category_value].append({
                        "id": item["id"],
                        "task": task,
                        "img_filename": img_filename,
                        "pred_text": str(error),
                        "gt_bbox": gt_bbox,
                        "success": 0
                    })
                    
                    # 记录结果（二次定位）
                    results_two_stage[category_type][category_value].append({
                        "id": item["id"],
                        "task": task,
                        "img_filename": img_filename,
                        "pred_text": str(error),
                        "gt_bbox": gt_bbox,
                        "success": 0
                    })
            
            # 输出当前评测结果
            print(f"\n当前样本: ID={item['id']}, 应用={item.get('application', 'unknown')}, 平台={item.get('platform', 'unknown')}, 任务=\"{task}\"")
            print(f"预测结果: 失败 (解析错误)")
            print(f"第一次预测点: 失败")
            print(f"真实区域: [{gt_bbox[0]}, {gt_bbox[1]}, {gt_bbox[2]}, {gt_bbox[3]}]")
            
            continue
        
        # 获取ground truth bbox
        gt_bbox = item["bbox"]
        
        # 判断第一次预测是否成功
        first_success = point_in_bbox(first_pred_point, gt_bbox, (img_width, img_height))
        
        # 更新成功计数
        if first_success:
            for category_type in categories:
                if category_type in item:
                    category_value = item[category_type]
                    success_count_single[category_type][category_value] += 1
                    # 如果第一次成功，任一成功计数也加1
                    success_count_either[category_type][category_value] += 1
        
        # 记录第一次预测结果到各个分类中
        for category_type in categories:
            if category_type in item:
                category_value = item[category_type]
                results[category_type][category_value].append({
                    "id": item["id"],
                    "task": task,
                    "img_filename": img_filename,
                    "pred_point": first_pred_point,
                    "gt_bbox": gt_bbox,
                    "success": 1 if first_success else 0
                })
        
        # 二次定位：从原图获取子区域
        subregion, bbox = get_subregion(image, first_pred_point, scale=0.25)
        
        # 保存可视化结果（可选）
        try:
            # 使用ID的最后两位数字决定是否保存可视化结果
            item_id = item["id"]
            id_num = int(item_id.split('_')[-1])
            save_vis = id_num % 20 == 0
        except (ValueError, TypeError, IndexError):
            # 如果id不是预期格式，则使用其他条件决定是否保存
            save_vis = False
            
        if save_vis:  # 每20个样本保存一次可视化结果
            # 创建可视化图像
            vis_image = image.copy()
            draw = ImageDraw.Draw(vis_image)
            
            # 绘制第一次预测点（蓝色）
            x1, y1 = first_pred_point[0] * vis_image.width, first_pred_point[1] * vis_image.height
            draw.ellipse((x1 - 10, y1 - 10, x1 + 10, y1 + 10), fill='blue')
            
            # 绘制子区域边框（绿色）
            draw.rectangle(bbox, outline='green', width=2)
            
            # 保存第一阶段可视化结果
            vis_path = os.path.join(vis_dir, f"{item['id']}_stage1.png")
            vis_image.save(vis_path)
        
        # 在子区域上进行第二次预测
        second_pred_point, error = predict_location(model, processor, subregion, task, system_prompt)
        
        if error:
            # 第二次预测失败，使用第一次预测结果
            print(f"第二次预测失败: {error}，使用第一次预测结果")
            
            # 记录结果到各个分类中
            for category_type in categories:
                if category_type in item:
                    category_value = item[category_type]
                    results_two_stage[category_type][category_value].append({
                        "id": item["id"],
                        "task": task,
                        "img_filename": img_filename,
                        "pred_point": first_pred_point,
                        "gt_bbox": gt_bbox,
                        "success": 1 if first_success else 0,
                        "stage": "一次定位（二次失败）"
                    })
            
            # 如果第一次成功，则二次定位也算成功
            if first_success:
                for category_type in categories:
                    if category_type in item:
                        category_value = item[category_type]
                        success_count_two_stage[category_type][category_value] += 1
                
            # 输出当前评测结果
            print(f"\n当前样本: ID={item['id']}, 应用={item.get('application', 'unknown')}, 平台={item.get('platform', 'unknown')}, 任务=\"{task}\"")
            print(f"预测结果: 单阶段={'成功' if first_success else '失败'}, 双阶段={'成功(使用单阶段结果)' if first_success else '失败'}")
            print(f"第一次预测点: [{first_pred_point[0]:.4f}, {first_pred_point[1]:.4f}]")
            print(f"第二次预测点: 失败")
            print(f"最终预测点: [{first_pred_point[0]:.4f}, {first_pred_point[1]:.4f}] (使用第一次预测结果)")
            print(f"真实区域: [{gt_bbox[0]}, {gt_bbox[1]}, {gt_bbox[2]}, {gt_bbox[3]}]")
            
            continue
        
        # 将子区域内的坐标转换回原图坐标
        left, top, right, bottom = bbox
        final_x = (left + second_pred_point[0] * (right - left)) / image.width
        final_y = (top + second_pred_point[1] * (bottom - top)) / image.height
        final_pred_point = [final_x, final_y]
        
        # 判断最终预测是否成功
        final_success = point_in_bbox(final_pred_point, gt_bbox, (img_width, img_height))
        
        # 更新成功计数
        if final_success:
            for category_type in categories:
                if category_type in item:
                    category_value = item[category_type]
                    success_count_two_stage[category_type][category_value] += 1
                    # 如果第二次成功且第一次未成功，更新任一成功计数
                    if not first_success:
                        success_count_either[category_type][category_value] += 1
        
        # 记录二次定位结果到各个分类中
        for category_type in categories:
            if category_type in item:
                category_value = item[category_type]
                results_two_stage[category_type][category_value].append({
                    "id": item["id"],
                    "task": task,
                    "img_filename": img_filename,
                    "first_pred_point": first_pred_point,
                    "second_pred_point": second_pred_point,
                    "final_pred_point": final_pred_point,
                    "gt_bbox": gt_bbox,
                    "success": 1 if final_success else 0
                })
        
        # 输出当前评测结果
        print(f"\n当前样本: ID={item['id']}, 应用={item.get('application', 'unknown')}, 平台={item.get('platform', 'unknown')}, 任务=\"{task}\"")
        print(f"预测结果: 单阶段={'成功' if first_success else '失败'}, 双阶段={'成功' if final_success else '失败'}, 任一成功={'成功' if (first_success or final_success) else '失败'}")
        print(f"第一次预测点: [{first_pred_point[0]:.4f}, {first_pred_point[1]:.4f}]")
        print(f"第二次预测点: [{second_pred_point[0]:.4f}, {second_pred_point[1]:.4f}] (子区域内)")
        print(f"最终预测点: [{final_pred_point[0]:.4f}, {final_pred_point[1]:.4f}] (转换回原图)")
        print(f"真实区域: [{gt_bbox[0]}, {gt_bbox[1]}, {gt_bbox[2]}, {gt_bbox[3]}]")
        
        # 输出当前类别的成功率
        for category_type in categories:
            if category_type in item:
                category_value = item[category_type]
                count = total_count[category_type][category_value]
                single_success = success_count_single[category_type][category_value]
                two_stage_success = success_count_two_stage[category_type][category_value]
                either_success = success_count_either[category_type][category_value]
                
                print(f"{category_type}={category_value} 当前成功率: 单阶段={single_success}/{count}={single_success/count:.4f}, "
                      f"双阶段={two_stage_success}/{count}={two_stage_success/count:.4f}, "
                      f"任一成功={either_success}/{count}={either_success/count:.4f}")
        
        # 保存可视化结果（可选）
        if save_vis:  # 使用之前计算的save_vis变量
            # 创建可视化图像
            vis_image = image.copy()
            draw = ImageDraw.Draw(vis_image)
            
            # 绘制第一次预测点（蓝色）
            x1, y1 = first_pred_point[0] * vis_image.width, first_pred_point[1] * vis_image.height
            draw.ellipse((x1 - 10, y1 - 10, x1 + 10, y1 + 10), fill='blue')
            
            # 绘制最终预测点（红色）
            x2, y2 = final_pred_point[0] * vis_image.width, final_pred_point[1] * vis_image.height
            draw.ellipse((x2 - 10, y2 - 10, x2 + 10, y2 + 10), fill='red')
            
            # 绘制子区域边框（绿色）
            draw.rectangle(bbox, outline='green', width=2)
            
            # 绘制真实bbox（黄色）
            x1, y1, x2, y2 = gt_bbox
            draw.rectangle((x1, y1, x2, y2), outline='yellow', width=2)
            
            # 保存最终可视化结果
            vis_path = os.path.join(vis_dir, f"{item['id']}_final.png")
            vis_image.save(vis_path)

    # 计算各分类的成功率
    metrics = {}
    metrics_two_stage = {}
    metrics_either = {}
    
    for category_type in categories:
        metrics[category_type] = {}
        metrics_two_stage[category_type] = {}
        metrics_either[category_type] = {}
        
        # 计算单阶段成功率
        for category_value in categories[category_type]:
            if total_count[category_type][category_value] > 0:
                metrics[category_type][category_value] = success_count_single[category_type][category_value] / total_count[category_type][category_value]
                metrics_two_stage[category_type][category_value] = success_count_two_stage[category_type][category_value] / total_count[category_type][category_value]
                metrics_either[category_type][category_value] = success_count_either[category_type][category_value] / total_count[category_type][category_value]
    
    # 计算整体成功率
    for category_type in categories:
        total = sum(total_count[category_type].values())
        if total > 0:
            metrics[category_type]["overall"] = sum(success_count_single[category_type].values()) / total
            metrics_two_stage[category_type]["overall"] = sum(success_count_two_stage[category_type].values()) / total
            metrics_either[category_type]["overall"] = sum(success_count_either[category_type].values()) / total

    # 打印结果
    for category_type in categories:
        print(f"\n按{category_type}分类的评测结果：")
        print("="*30)
        
        print("\n单阶段定位：")
        for category_value, success_rate in metrics[category_type].items():
            if category_value != "overall":
                print(f"{category_value} 成功率: {success_rate:.4f}")
        print(f"整体成功率: {metrics[category_type].get('overall', 0):.4f}")
        
        print("\n双阶段定位：")
        for category_value, success_rate in metrics_two_stage[category_type].items():
            if category_value != "overall":
                print(f"{category_value} 成功率: {success_rate:.4f}")
        print(f"整体成功率: {metrics_two_stage[category_type].get('overall', 0):.4f}")
        
        print("\n任一成功：")
        for category_value, success_rate in metrics_either[category_type].items():
            if category_value != "overall":
                print(f"{category_value} 成功率: {success_rate:.4f}")
        print(f"整体成功率: {metrics_either[category_type].get('overall', 0):.4f}")
        
        print("\n双阶段相对单阶段的提升：")
        for category_value in metrics[category_type]:
            if category_value != "overall" and category_value in metrics_two_stage[category_type]:
                improvement = metrics_two_stage[category_type][category_value] - metrics[category_type][category_value]
                if metrics[category_type][category_value] > 0:
                    relative_improvement = improvement / metrics[category_type][category_value] * 100
                    print(f"{category_value}: {improvement:.4f} ({relative_improvement:.2f}%)")
        
        if "overall" in metrics[category_type] and "overall" in metrics_two_stage[category_type]:
            overall_improvement = metrics_two_stage[category_type]["overall"] - metrics[category_type]["overall"]
            if metrics[category_type]["overall"] > 0:
                overall_relative_improvement = overall_improvement / metrics[category_type]["overall"] * 100
                print(f"整体: {overall_improvement:.4f} ({overall_relative_improvement:.2f}%)")

    # 保存结果
    output_dir = "results/pro_1000_1344_ori"
    os.makedirs(output_dir, exist_ok=True)

    # 保存详细结果
    for category_type in categories:
        category_dir = os.path.join(output_dir, category_type)
        os.makedirs(category_dir, exist_ok=True)
        
        with open(os.path.join(category_dir, "results_single.json"), "w", encoding="utf-8") as f:
            json.dump(results[category_type], f, ensure_ascii=False, indent=2)
        
        with open(os.path.join(category_dir, "results_two_stage.json"), "w", encoding="utf-8") as f:
            json.dump(results_two_stage[category_type], f, ensure_ascii=False, indent=2)
        
        with open(os.path.join(category_dir, "metrics_single.json"), "w", encoding="utf-8") as f:
            json.dump(metrics[category_type], f, ensure_ascii=False, indent=2)
        
        with open(os.path.join(category_dir, "metrics_two_stage.json"), "w", encoding="utf-8") as f:
            json.dump(metrics_two_stage[category_type], f, ensure_ascii=False, indent=2)
        
        with open(os.path.join(category_dir, "metrics_either.json"), "w", encoding="utf-8") as f:
            json.dump(metrics_either[category_type], f, ensure_ascii=False, indent=2)

    # 保存汇总结果
    with open(os.path.join(output_dir, "summary_metrics.json"), "w", encoding="utf-8") as f:
        summary = {
            "single": {cat: metrics[cat].get("overall", 0) for cat in categories},
            "two_stage": {cat: metrics_two_stage[cat].get("overall", 0) for cat in categories},
            "either": {cat: metrics_either[cat].get("overall", 0) for cat in categories}
        }
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("\n评测完成，结果已保存到", output_dir)

if __name__ == "__main__":
    main()